package com.example.bitmock;

public class Asset {
    private String coinName;
    private int coinCount;
    private String sumPrice;
    private double revenue;

    public Asset(String coinName, int coinCount, String sumPrice, double revenue) {
        this.coinName = coinName;
        this.coinCount = coinCount;
        this.sumPrice = sumPrice;
        this.revenue = revenue;
    }

    public String getCoinName() {
        return coinName;
    }

    public int getCoinCount() {
        return coinCount;
    }

    public String getSumPrice() {
        return sumPrice;
    }

    public double getRevenue() {
        return revenue;
    }
}
