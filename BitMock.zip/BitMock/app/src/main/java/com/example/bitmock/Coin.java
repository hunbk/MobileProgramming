package com.example.bitmock;

public class Coin {
    private String coinName;
    private String price;
    private String fluctuateRate;

    public Coin(String coinName, String price, String fluctuateRate) {
        this.coinName = coinName;
        this.price = price;
        this.fluctuateRate = fluctuateRate;
    }

    public String getCoinName() {
        return coinName;
    }

    public String getPrice() {
        return price;
    }

    public String getFluctuateRate() {
        return fluctuateRate;
    }

}
