package com.example.bitmock;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;

public class AssetFragment extends Fragment {
    ListView listView;
    AssetListViewAdapter adapter;
    ArrayList<Asset> assets;
    ArrayList<AssetDTO> assetDTOS;
    DBHelper dbHelper;
    String strUrl = "https://api.bithumb.com/public/ticker/all";
    Button btnRefresh;
    String[] coinTag = {"BTC", "ETH", "XRP", "LUNA", "EOS", "LTC", "KLAY"};
    String[] coinName = {"비트코인", "이더리움", "리플", "루나", "이오스", "라이트코인", "클레이튼"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_asset, container, false);

        assets = new ArrayList<>();

        dbHelper = new DBHelper(getActivity());

        getAssetData();

        listView = rootView.findViewById(R.id.assetListView);
        adapter = new AssetListViewAdapter(getActivity(), assets);
        listView.setAdapter(adapter);

        btnRefresh = rootView.findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getAssetData();
                adapter.notifyDataSetChanged();
            }
        });

        return rootView;
    }

    public void getAssetData() {
        assets.clear();

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(strUrl);
                    InputStream is = url.openStream();
                    InputStreamReader isr = new InputStreamReader(is);
                    BufferedReader reader = new BufferedReader(isr);

                    StringBuffer buffer = new StringBuffer();
                    String line = reader.readLine();
                    while (line != null) {
                        buffer.append(line + "\n");
                        line = reader.readLine();
                    }

                    String jsonData = buffer.toString();

                    JSONObject jsonObject = new JSONObject(jsonData).getJSONObject("data");
                    String name;
                    int coinCount;
                    long price;
                    String sumPrice;
                    double revenue = 0;
                    double avg = 0;

                    assetDTOS = dbHelper.getAsset(MainActivity.userId);
                    for (AssetDTO assetDTO : assetDTOS) {
                        JSONObject coin = jsonObject.getJSONObject(assetDTO.getCoinName().toUpperCase());

                        price = Integer.parseInt(coin.getString("closing_price"));
                        coinCount = assetDTO.getCoinCount();
                        name = coinName[Arrays.asList(coinTag).indexOf(assetDTO.getCoinName().toUpperCase())];

                        avg = dbHelper.getAvg(MainActivity.userId, assetDTO.getCoinName());
                        revenue = ((price - avg) / avg) * 100;

                        DecimalFormat decimalFormat = new DecimalFormat("###,###");
                        sumPrice = decimalFormat.format(price * coinCount);
                        assets.add(new Asset(name, coinCount, sumPrice, revenue));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}