package com.example.bitmock;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class AssetListViewAdapter extends BaseAdapter {
    Context context = null;
    ArrayList<Asset> items = null;

    public AssetListViewAdapter(Context context, ArrayList<Asset> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.listview_custom_asset, viewGroup, false);

        TextView coinName = (TextView) view.findViewById(R.id.asset_coinName);
        TextView coinCount = (TextView) view.findViewById(R.id.asset_coinCount);
        TextView sumPrice = (TextView) view.findViewById(R.id.sumPrice);
        TextView revenue = (TextView) view.findViewById(R.id.revenue);

        coinName.setText(items.get(position).getCoinName());
        coinCount.setText(Integer.toString(items.get(position).getCoinCount()));
        sumPrice.setText(items.get(position).getSumPrice() + "원");
        revenue.setText(String.format("%.2f", items.get(position).getRevenue())+"%");
        return view;
    }
}
