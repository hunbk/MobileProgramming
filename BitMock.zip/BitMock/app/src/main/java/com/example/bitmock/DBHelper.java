package com.example.bitmock;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static DBHelper dbHelper = null;

    static SQLiteDatabase db;

    public static DBHelper getInstance(Context context) {
        if (dbHelper == null) {
            dbHelper = new DBHelper(context);
        }

        return dbHelper;
    }

    public DBHelper(@Nullable Context context) {
        super(context, "bitMockDB", null, 1);
        db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE user (" +
                "userId CHAR(20) PRIMARY KEY" + ", " +
                "password CHAR(20)" + ", " +
                "nickName CHAR(20)" +
                ")"
        );
        db.execSQL("CREATE TABLE asset (" +
                "userId CHAR(20) PRIMARY KEY" + ", " +
                "btc INTEGER" + ", " + "avgbtc REAL" + ", " +
                "eth INTEGER" + ", " + "avgeth REAL" + ", " +
                "xrp INTEGER" + ", " + "avgxrp REAL" + ", " +
                "luna INTEGER" + ", " + "avgluna REAL" + ", " +
                "eos INTEGER" + ", " + "avgeos REAL" + ", " +
                "ltc INTEGER" + ", " + "avgltc REAL" + ", " +
                "klay INTEGER" +", " + "avgklay REAL" +
                ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS asset");
        onCreate(db);
    }

    public void insertUser(String id, String pw, String nick) {
        db.execSQL("INSERT INTO user VALUES('" +
                id + "', '" +
                pw + "', '" +
                nick + "'" +
                ")"
        );

        db.execSQL("INSERT INTO asset VALUES('" +
                id + "', " +
                "0,0,0,0,0,0,0,0,0,0,0,0,0,0)"
        );
    }

    public String findUser(String id, String pw) {
        Cursor cursor;
        String result;
        cursor = db.rawQuery("SELECT userId FROM user WHERE userId = '" + id + "' AND password = '" + pw + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() == 0) {
            return "";
        }

        result = cursor.getString(0);
        return result;
    }

    public int getCoinCount(String id, String coinTag) {
        Cursor cursor;
        int cnt;
        cursor = db.rawQuery("SELECT " + coinTag + " FROM asset WHERE userId = '" + id + "'", null);
        cursor.moveToFirst();
        cnt = cursor.getInt(0);
        return cnt;
    }

    public double getAvg(String id, String coinTag) {
        double avg;
        Cursor cursor;
        cursor = db.rawQuery("SELECT " + "avg" + coinTag  + " FROM asset WHERE userId = " + "'" + id + "'", null);
        cursor.moveToFirst();
        avg = cursor.getDouble(0);
        return avg;
    }

    public void updateCoinCount(String id, String coinTag, int amount, double avg) {
        db.execSQL("UPDATE asset SET " + coinTag + " = " + amount + ", avg" + coinTag + " = " + avg +" WHERE userId = '" + id + "'");
    }

    public ArrayList<AssetDTO> getAsset(String id) {
        String coinName;
        int position, coinCount, avgPrice;
        ArrayList<AssetDTO> assets = new ArrayList<>();
        Cursor cursor;
        cursor = db.rawQuery("SELECT * FROM asset WHERE userId = " + "'" + id + "'", null);
        cursor.moveToFirst();
        position = 1;

        for (int i = 0; i < (cursor.getColumnCount() - 1)/2 ; i++) {
            coinName = cursor.getColumnName(position);
            coinCount = cursor.getInt(position++);
            avgPrice = cursor.getInt(position++);

            if (coinCount > 0) {
                assets.add(new AssetDTO(coinName, coinCount, avgPrice));
            }
        }
        return assets;
    }
}
