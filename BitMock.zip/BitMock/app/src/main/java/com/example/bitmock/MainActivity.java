package com.example.bitmock;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    HomeFragment homeFragment;
    AssetFragment assetFragment;
    BoardFragment boardFragment;

    TextView headerTitle;
    ImageButton btnInfo;
    static String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        userId = intent.getStringExtra("userId");
        Toast.makeText(getApplicationContext(),userId + "님 환영합니다.",Toast.LENGTH_SHORT).show();


        btnInfo = findViewById(R.id.btnInfo);
        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, InfoActivity.class);
                startActivity(intent);
            }
        });

        homeFragment = new HomeFragment();
        assetFragment = new AssetFragment();
        boardFragment = new BoardFragment();

        headerTitle = findViewById(R.id.headerTitle);

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, homeFragment).commit();
        headerTitle.setText("거래소");

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, homeFragment).commit();
                        headerTitle.setText("거래소");
                        return true;

                    case R.id.navigation_asset:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, assetFragment).commit();
                        headerTitle.setText("자산");
                        return true;

                    case R.id.navigation_board:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, boardFragment).commit();
                        headerTitle.setText("토론");
                        return true;
                }
                return false;
            }
        });

    }
}