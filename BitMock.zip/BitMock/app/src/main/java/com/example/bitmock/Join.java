package com.example.bitmock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Join extends AppCompatActivity {
    EditText id, password, nickname;
    Button btnJoin;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        id = (EditText) findViewById(R.id.joinId);
        password = (EditText) findViewById(R.id.joinPassword);
        nickname = (EditText) findViewById(R.id.joinNickname);

        dbHelper = new DBHelper(this);

        btnJoin = findViewById(R.id.btnJoin);
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHelper.insertUser(id.getText().toString(), password.getText().toString(), nickname.getText().toString());
                Toast.makeText(getApplicationContext(),"회원가입 완료",Toast.LENGTH_SHORT).show();
                Join.this.finish();
            }
        });
    }
}