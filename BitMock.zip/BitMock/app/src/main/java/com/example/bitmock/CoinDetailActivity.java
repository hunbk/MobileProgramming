package com.example.bitmock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class CoinDetailActivity extends AppCompatActivity {
    TextView coinName, price, coinCount;
    EditText orderCount;
    DBHelper dbHelper;
    Button btnBuy, btnSell;
    int coinAmount, orderAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_detail);

        coinName = (TextView) findViewById(R.id.detailCoinName);
        price = (TextView) findViewById(R.id.price);
        coinCount = (TextView) findViewById(R.id.coinCount);

        dbHelper = new DBHelper(this);

        Intent intent = getIntent();
        coinName.setText(intent.getStringExtra("coinName"));

        DecimalFormat decimalFormat = new DecimalFormat("###,###");
        price.setText(decimalFormat.format(Integer.parseInt(intent.getStringExtra("price")))+ "원");

        String coinTag = intent.getStringExtra("coinTag");
        coinAmount = dbHelper.getCoinCount(MainActivity.userId, coinTag);
        coinCount.setText("보유 수량 "+ coinAmount);

        orderCount = findViewById(R.id.orderCount);

        btnBuy = findViewById(R.id.btnBuy);
        btnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int amount;
                double avg;
                double tmp;

                if (orderCount.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(),"주문 수량을 입력하세요.",Toast.LENGTH_SHORT).show();
                    return;
                }

                orderAmount = Integer.parseInt(orderCount.getText().toString());
                amount = orderAmount + coinAmount;

                // 평균 구매가 = ((평균 구매가 * 보유 수량) + (현재 가격 * 주문 수량)) / 보유수량 + 주문수량
                avg = dbHelper.getAvg(MainActivity.userId, coinTag);
                tmp = ((avg * coinAmount) + (Integer.parseInt(intent.getStringExtra("price")) * orderAmount)) / amount;
                avg = tmp;

                System.out.println(avg);
                dbHelper.updateCoinCount(MainActivity.userId, coinTag, amount, avg);
                Toast.makeText(getApplicationContext(),"매수 완료",Toast.LENGTH_SHORT).show();
                CoinDetailActivity.this.finish();
            }
        });

        btnSell = findViewById(R.id.btnSell);
        btnSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int amount;
                double avg;

                if (orderCount.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(),"주문 수량을 입력하세요.",Toast.LENGTH_SHORT).show();
                    return;
                }

                orderAmount = Integer.parseInt(orderCount.getText().toString());
                if (coinAmount < orderAmount) {
                    Toast.makeText(getApplicationContext(),"보유 수량을 초과할 수 없습니다.",Toast.LENGTH_SHORT).show();
                    return;
                }

                amount = coinAmount - orderAmount;

                avg = dbHelper.getAvg(MainActivity.userId, coinTag);

                if (amount == 0) {
                    avg = 0;
                }

                dbHelper.updateCoinCount(MainActivity.userId, coinTag, amount, avg);
                Toast.makeText(getApplicationContext(),"매도 완료",Toast.LENGTH_SHORT).show();
                CoinDetailActivity.this.finish();
            }
        });
    }
}