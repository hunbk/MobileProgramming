package com.example.bitmock;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class HomeListViewAdapter extends BaseAdapter {
    Context context = null;
    ArrayList<Coin> items = null;

    public HomeListViewAdapter(Context context, ArrayList<Coin> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.listview_custom_home, viewGroup, false);

        TextView coinName = (TextView) view.findViewById(R.id.coinName);
        TextView price = (TextView) view.findViewById(R.id.price);
        TextView fluctuateRate = (TextView) view.findViewById(R.id.fluctuateRate);

        coinName.setText(items.get(position).getCoinName());

        DecimalFormat decimalFormat = new DecimalFormat("###,###");
        price.setText(decimalFormat.format(Integer.parseInt(items.get(position).getPrice())));
        fluctuateRate.setText(items.get(position).getFluctuateRate());

        return view;
    }
}
