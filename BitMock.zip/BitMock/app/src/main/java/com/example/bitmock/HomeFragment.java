package com.example.bitmock;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class HomeFragment extends Fragment {
    ListView listView;
    HomeListViewAdapter adapter;
    ArrayList<Coin> coins;
    String strUrl = "https://api.bithumb.com/public/ticker/all";
    Button btnRefresh;
    String[] coinTag = {"BTC", "ETH", "XRP", "LUNA", "EOS", "LTC", "KLAY"};
    String[] coinName = {"비트코인", "이더리움", "리플", "루나", "이오스", "라이트코인", "클레이튼"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        coins = new ArrayList<>();
        getCoinData();

        listView = rootView.findViewById(R.id.homeListView);
        adapter = new HomeListViewAdapter(getActivity(), coins);
        listView.setAdapter(adapter);

        btnRefresh = rootView.findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCoinData();
                adapter.notifyDataSetChanged();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), CoinDetailActivity.class);
                intent.putExtra("coinName", coins.get(position).getCoinName());
                intent.putExtra("price", coins.get(position).getPrice());
                intent.putExtra("coinTag", coinTag[position]);
                startActivity(intent);
            }
        });

        return rootView;
    }

    public void getCoinData() {
        coins.clear();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(strUrl);
                    InputStream is = url.openStream();
                    InputStreamReader isr = new InputStreamReader(is);
                    BufferedReader reader = new BufferedReader(isr);

                    StringBuffer buffer = new StringBuffer();
                    String line = reader.readLine();
                    while (line != null) {
                        buffer.append(line + "\n");
                        line = reader.readLine();
                    }

                    String jsonData = buffer.toString();

                    JSONObject jsonObject = new JSONObject(jsonData).getJSONObject("data");
                    String name, price, fluctuateRate;

                    for (int i = 0; i < coinTag.length; i++) {
                        JSONObject coin = jsonObject.getJSONObject(coinTag[i]);
                        name = coinName[i];
                        price = coin.getString("closing_price");
                        fluctuateRate = coin.getString("fluctate_rate_24H") + "%";
                        coins.add(new Coin(name, price, fluctuateRate));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}