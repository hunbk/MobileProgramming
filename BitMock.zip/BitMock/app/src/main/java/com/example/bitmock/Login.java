package com.example.bitmock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText loginId, loginPassword;
    Button btnLogin, btnJoin;
    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);

        dbHelper = new DBHelper(this);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id, pw;
                id = loginId.getText().toString();
                pw = loginPassword.getText().toString();
                if (id.equals("") || pw.equals("")) {
                    Toast.makeText(getApplicationContext(),"아이디, 비밀번호를 입력하세요.",Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dbHelper.findUser(id, pw).equals(id)) {
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    intent.putExtra("userId", id);
                    startActivity(intent);
                    Login.this.finish();
                } else {
                    Toast.makeText(getApplicationContext(),"아이디와 비밀번호를 정확히 입력해 주세요.",Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnJoin = findViewById(R.id.btnJoin);
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Join.class);
                startActivity(intent);
            }
        });
    }
}