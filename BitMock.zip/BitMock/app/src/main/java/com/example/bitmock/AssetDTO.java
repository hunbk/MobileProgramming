package com.example.bitmock;

public class AssetDTO {
    private String coinName;
    private int coinCount;
    private int avgPrice;

    public AssetDTO(String coinName, int coinCount, int avgPrice) {
        this.coinName = coinName;
        this.coinCount = coinCount;
        this.avgPrice = avgPrice;
    }

    public String getCoinName() {
        return coinName;
    }

    public int getCoinCount() {
        return coinCount;
    }

    public int getAvgPrice() {
        return avgPrice;
    }
}
